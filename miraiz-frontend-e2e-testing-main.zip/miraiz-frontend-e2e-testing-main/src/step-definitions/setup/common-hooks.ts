import { ChromiumBrowser, chromium } from "@playwright/test";
import {
  After,
  AfterAll,
  Before,
  BeforeAll,
  ITestCaseHookParameter,
  Status,
  setDefaultTimeout,
} from "@cucumber/cucumber";
import { ICustomWorld } from "./custom-world";
import { takeScreenshot } from "../../utils/helpers";
import { AUTH_FILE } from "../../constants/common";

let browser: ChromiumBrowser;

setDefaultTimeout(60 * 1000);

BeforeAll(async function () {
  const options = {
    headless: false,
    channel: "chrome",
    slowMo: 1000,
    args: ["--disable-blink-features=AutomationControlled"],
  };

  browser = await chromium.launch(options);
});

Before(async function (this: ICustomWorld) {
  this.context = await browser.newContext({
    storageState: AUTH_FILE,
  });
  this.page = await this.context.newPage();
});

After(async function (this: ICustomWorld, scenario: ITestCaseHookParameter) {
  if (scenario.result?.status !== Status.PASSED) {
    const world = this;
    await takeScreenshot(scenario, world);
  }
  await this.page?.close();
  await this.context?.close();
});

AfterAll(async function () {
  await browser.close();
});
