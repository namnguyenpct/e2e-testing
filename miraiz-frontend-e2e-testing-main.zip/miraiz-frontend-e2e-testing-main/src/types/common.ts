export type AuthAction = "login" | "register";

export type AuthCondition =
  | "empty email"
  | "empty password"
  | "incorrect email"
  | "incorrect password"
  | "valid credential"
  | "uncheck terms"
  | "incorrect confirm password"
  | "invalid password"
  | "existed email";

export type LoginErrorType =
  | "missing required field"
  | "invalid"
  | "incorrect"
  | "not match password"
  | "not strong password"
  | "existed email";
