import { Given, Then, When } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import {
  FORM_FIELD_SELECTORS,
  BUTTON_SELECTORS,
  ERROR_SELECTORS,
} from "../constants/selectors";
import { VALID_ACCOUNT } from "../constants/common";
import { AuthAction, AuthCondition, LoginErrorType } from "../types/common";
import { ICustomWorld } from "./setup/custom-world";
import { getVerificationCode } from "../utils/helpers";

Given("user go to login page", async function (this: ICustomWorld) {
  // Arrange
  const page = this.page!;
  const gotoLoginButton = page!
    .getByRole("link")
    .filter({ hasText: "ログイン" })
    .first();
  await gotoLoginButton.waitFor();
  await gotoLoginButton.click();

  // Act
  const emailLabel = page.getByLabel(FORM_FIELD_SELECTORS.EMAIL_LABEL);
  const passwordLabel = page.getByLabel(FORM_FIELD_SELECTORS.PASSWORD_LABEL);

  await emailLabel.waitFor();
  await passwordLabel.waitFor();

  // Assert
  await expect(emailLabel).toBeVisible();
  await expect(passwordLabel).toBeVisible();
});

When(
  "user login with {string}",
  async function (this: ICustomWorld, condition: AuthCondition) {
    // Arrange
    const page = this.page!;

    let email = VALID_ACCOUNT.email;
    let password = VALID_ACCOUNT.password;

    switch (condition) {
      case "empty email":
        email = "";
        break;
      case "empty password":
        password = "";
        break;
      case "incorrect email":
        email = "incorrect email";
        break;
      case "incorrect password":
        password = "incorrect password";
        break;
      default:
        break;
    }

    const emailInput = page.getByPlaceholder(
      FORM_FIELD_SELECTORS.EMAIL_PLACEHOLDER
    );
    const passwordInput = page.getByPlaceholder(
      FORM_FIELD_SELECTORS.PASSWORD_PLACEHOLDER
    );

    // Act
    await emailInput.fill(email);
    await passwordInput.fill(password);

    // Assert
    await page.locator(BUTTON_SELECTORS.LOGIN).click();
    await page.waitForTimeout(2000);
  }
);

Then(
  "user get {string} verification code",
  async function (this: ICustomWorld, authAction: AuthAction) {
    // Arrange
    const page = this.page!;
    const context = this.context!;

    const verificationTitle = page.getByText("認証コードの入力");
    await verificationTitle.waitFor();
    await page.waitForTimeout(5000);

    // Act
    const code = await getVerificationCode(context);

    const codeInput =
      authAction === "login"
        ? page.locator(FORM_FIELD_SELECTORS.VERIFICATION_CODE_INPUT)
        : page.getByLabel(
            FORM_FIELD_SELECTORS.REGISTER_VERIFICATION_CODE_INPUT
          );

    await codeInput.waitFor();

    codeInput.fill(code?.trim() || "");

    if (authAction === "login") {
      await page.locator("div[role=button]").getByText("次へ").click();
    } else {
      await page.getByRole("heading").first().click();
      await page.locator("input[value=次へ]").click();
    }
  }
);

Then(
  "user sees {string} error message",
  async function (this: ICustomWorld, errorType: LoginErrorType) {
    // Arrange
    const page = this.page!;

    // Assert
    switch (errorType) {
      case "missing required field":
        await expect(
          page.getByText(ERROR_SELECTORS.MISSING_REQUIRED_FIELD)
        ).toBeVisible();
        break;
      case "incorrect":
        await expect(
          page.getByText(ERROR_SELECTORS.INCORRECT_CREDENTIAL)
        ).toBeVisible();
        break;
      case "not match password":
        await expect(
          page.getByText(ERROR_SELECTORS.INVALID_PASSWORD)
        ).toBeVisible();
        break;
      case "not strong password":
        await expect(
          page.getByText(ERROR_SELECTORS.NOT_STRONG_PASSWORD)
        ).toBeVisible();
        break;
      case "existed email":
        await expect(
          page.getByText(ERROR_SELECTORS.EXISTED_EMAIL)
        ).toBeVisible();
        break;
      default:
        break;
    }
  }
);

Then("user login successfully", async function (this: ICustomWorld) {
  // Arrange
  const page = this.page!;

  const userTab = page.getByText("マイページ");
  await userTab.waitFor();

  // Assert
  await expect(userTab).toBeVisible();
});
