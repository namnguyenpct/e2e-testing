import "dotenv/config";

export const IAP_ACCOUNT = {
  email: process.env.IAP_ACCOUNT_EMAIL || "",
  password: process.env.IAP_ACCOUNT_PASSWORD || "",
};

export const VALID_ACCOUNT = {
  email: process.env.VALID_ACCOUNT_EMAIL || "",
  password: process.env.VALID_ACCOUNT_PASSWORD || "",
};

export const DEFAULT_ACCOUNT = {
  email: process.env.DEFAULT_ACCOUNT_EMAIL || "",
  password: process.env.DEFAULT_ACCOUNT_PASSWORD || "",
};

export const AUTH_FILE = process.env.AUTH_FILE || "";

export const MIRAIZ_LANDING_PAGE_URL = "https://dev00.miraiz-persol.jp";
