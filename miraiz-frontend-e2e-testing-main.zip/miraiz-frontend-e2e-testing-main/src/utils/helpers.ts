import { ITestCaseHookParameter } from "@cucumber/cucumber";
import { ICustomWorld } from "../step-definitions/setup/custom-world";
import { AUTH_FILE, IAP_ACCOUNT } from "../constants/common";
import { BrowserContext, Page } from "playwright";
import { GOOGLE_SELECTORS } from "../constants/selectors";

export const takeScreenshot = async (
  scenario: ITestCaseHookParameter,
  world: ICustomWorld
) => {
  const screenshotPath: string = "./reports/screenshots/";
  const screenshotExt: string = ".png";

  const screenShot = await world.page?.screenshot({
    path: screenshotPath + scenario.pickle.name + screenshotExt,
    fullPage: true,
  });

  if (screenShot) world.attach(screenShot, "image/png");
};

export const bypassIAP = async (page: Page, fallbackUrl: string) => {
  await page.goto("https://myaccount.google.com/?hl=en-US");

  const gAccountBtn = page
    .getByRole("link", { name: "Go to your Google Account" })
    .first();
  await gAccountBtn.click();

  const emailInput = page.locator(GOOGLE_SELECTORS.EMAIL_INPUT).first();
  await emailInput.fill(IAP_ACCOUNT.email);
  await page.locator(GOOGLE_SELECTORS.IDENTIFIER_NEXT_BUTTON).click();

  const passwordInput = page.locator(GOOGLE_SELECTORS.PASSOWORD_INPUT).first();

  await passwordInput.fill(IAP_ACCOUNT.password);
  await page.locator(GOOGLE_SELECTORS.CHECKBOX).click();
  await page.locator(GOOGLE_SELECTORS.PASSWORD_NEXT_BUTTON).click();

  await page.waitForURL(/^https:\/\/myaccount\.google\.com/);
  await page.context().storageState({ path: AUTH_FILE });
  await page.waitForTimeout(2000);

  await page.goto(fallbackUrl);
};

export const getVerificationCode = async (context: BrowserContext) => {
  const newPage = await context.newPage();

  await newPage.goto("https://mail.google.com/mail/u/0/#inbox");

  await newPage
    .getByRole("row")
    .getByText("PERSOL MIRAIZ（ミライズ）")
    .nth(1)
    .click();

  const code = await newPage
    .getByRole("cell")
    .getByText(/\b\d{6}\b/g, { exact: true })
    .last()
    .textContent();

  await newPage.close();

  return code;
};

export const addAliasToEmail = (gmail: string, alias: string): string => {
  return gmail.replace("@", `${alias}@`);
};
