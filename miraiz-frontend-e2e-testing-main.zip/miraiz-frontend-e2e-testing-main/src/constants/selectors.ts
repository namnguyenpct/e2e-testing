// google
export const GOOGLE_SELECTORS = {
  GOTO_GOOGLE_ACCOUNT_BUTTON: "Go to Google Account",
  EMAIL_INPUT: "input[type=email]",
  PASSOWORD_INPUT: "input[type=password]",
  CHECKBOX: "input[type=checkbox]",
  IDENTIFIER_NEXT_BUTTON: "div[id=identifierNext]",
  PASSWORD_NEXT_BUTTON: "div[id=passwordNext]",
};

// FORM FIELD
export const FORM_FIELD_SELECTORS = {
  EMAIL_LABEL: "メールアドレス（ログインID）",
  PASSWORD_LABEL: "パスワード",
  CONFIRM_PASSWORD_LABEL: "パスワード（確認）",
  EMAIL_PLACEHOLDER: "メールアドレス",
  PASSWORD_PLACEHOLDER: "パスワード",
  VERIFICATION_CODE_INPUT: "input[aria-label=認証コード（6桁の半角数字）]",
  REGISTER_VERIFICATION_CODE_INPUT: "認証コード（6桁の半角数字）",
  TERMS_CHECK_BOX_NAME: "preferences.terms.persolId.isConsentGranted",
};

// BUTTONS
export const BUTTON_SELECTORS = {
  LOGIN: "input[value=ログイン]",
  REGISTER: "input[value=登録]",
};

// ERRORS
export const ERROR_SELECTORS = {
  MISSING_REQUIRED_FIELD: "必須項目です。",
  INCORRECT_CREDENTIAL: "ログインIDまたはパスワードが間違っています。",
  NOT_STRONG_PASSWORD: "パスワードの強度が足りません。",
  INVALID_PASSWORD: "パスワードが一致しません。",
  EXISTED_EMAIL: "このメールアドレスは既に登録されています。",
};
