import { Given } from "@cucumber/cucumber";
import { ICustomWorld } from "./setup/custom-world";
import { bypassIAP } from "../utils/helpers";
import { MIRAIZ_LANDING_PAGE_URL } from "../constants/common";

Given("user is on the landing page", async function (this: ICustomWorld) {
  // Arrange
  const page = this.page!;

  // Act
  await page.goto(MIRAIZ_LANDING_PAGE_URL);

  const pageTitleVisible =
    (await page.getByText("スキルを育てて、キャリアに伴走する。").count()) > 0;

  if (!pageTitleVisible) {
    await bypassIAP(page, MIRAIZ_LANDING_PAGE_URL);
  }
});
