import { Given, Then, When } from "@cucumber/cucumber";
import { BUTTON_SELECTORS, FORM_FIELD_SELECTORS } from "../constants/selectors";
import { expect } from "playwright/test";
import { ICustomWorld } from "./setup/custom-world";
import { AuthCondition } from "../types/common";
import { DEFAULT_ACCOUNT, VALID_ACCOUNT } from "../constants/common";
import { addAliasToEmail } from "../utils/helpers";

Given("user go to register page", async function (this: ICustomWorld) {
  // Arrange
  const page = this.page!;
  await page.mouse.wheel(0, 800);
  await page.waitForTimeout(2000);

  const gotoRegisterButton = page!
    .getByRole("link")
    .filter({ hasText: "無料で新規登録" })
    .first();
  await gotoRegisterButton.waitFor();
  await gotoRegisterButton.click();

  // Act
  const emailLabel = page.getByText(FORM_FIELD_SELECTORS.EMAIL_LABEL, {
    exact: true,
  });
  const passwordLabel = page.getByText(FORM_FIELD_SELECTORS.PASSWORD_LABEL, {
    exact: true,
  });
  const confirmPasswordLabel = page.getByText(
    FORM_FIELD_SELECTORS.CONFIRM_PASSWORD_LABEL,
    { exact: true }
  );

  await emailLabel.waitFor();
  await passwordLabel.waitFor();
  await confirmPasswordLabel.waitFor();

  // Assert
  await expect(emailLabel).toBeVisible();
  await expect(passwordLabel).toBeVisible();
  await expect(confirmPasswordLabel).toBeVisible();
});

When(
  "user register with {string}",
  async function (this: ICustomWorld, condition: AuthCondition) {
    // Arrange
    const page = this.page!;

    const alias = `+e2e-${Math.floor(Math.random() * 10000)}`;
    let email = addAliasToEmail(DEFAULT_ACCOUNT.email, alias);
    let password = DEFAULT_ACCOUNT.password;
    let confirmPassword = DEFAULT_ACCOUNT.password;
    let termsChecked = true;

    switch (condition) {
      case "empty email":
        email = "";
        break;
      case "empty password":
        password = "";
        break;
      case "invalid password":
        password = "invalid-password";
        confirmPassword = "invalid-password";
        break;
      case "uncheck terms":
        termsChecked = false;
        break;
      case "incorrect confirm password":
        confirmPassword = "IncorrectPassword";
        break;
      case "existed email":
        email = VALID_ACCOUNT.email;
        break;
      default:
        break;
    }

    const emailInput = page.getByPlaceholder(
      FORM_FIELD_SELECTORS.EMAIL_PLACEHOLDER,
      { exact: true }
    );
    const passwordInput = page.getByPlaceholder(
      FORM_FIELD_SELECTORS.PASSWORD_PLACEHOLDER,
      { exact: true }
    );
    const confirmPasswordInput = page.getByPlaceholder(
      FORM_FIELD_SELECTORS.CONFIRM_PASSWORD_LABEL,
      { exact: true }
    );

    // Act
    await emailInput.fill(email);
    await passwordInput.fill(password);
    await confirmPasswordInput.fill(confirmPassword);

    if (termsChecked) {
      await page.getByRole("checkbox").first().click();
    }

    // Assert
    await page.locator(BUTTON_SELECTORS.REGISTER).click();
    await page.waitForTimeout(2000);
  }
);

Then("user register successfully", async function (this: ICustomWorld) {
  const page = this.page!;

  const title = page.getByRole("heading", {
    name: "メール認証が完了しました",
    exact: true,
  });

  await title.waitFor();

  expect(title).toBeVisible();
});
